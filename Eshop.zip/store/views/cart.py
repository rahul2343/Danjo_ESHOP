from django.shortcuts import render,redirect
from store.models.costomer import Customer
from django.contrib.auth.hashers import check_password
from django.views import View
from store.models.product import Project

class Cart(View):
    def get(self, request):
        ids = (list(request.session.get('cart').keys()))
        products = Project.get_product_by_id(ids)
        print(products)
        return render(request,'cart.html', {'products':products})