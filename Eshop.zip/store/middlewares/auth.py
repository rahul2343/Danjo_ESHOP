from django.shortcuts import redirect


def auth_middleware(get_response):

    def middleware(requrest):
        #if not requrest.session.get('customer'):
         #   return redirect('login')

        response = get_response(requrest)
        return response
    return middleware







