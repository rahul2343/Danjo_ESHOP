from django.contrib import admin
from .models.product import Project
from .models.Category import Category
from .models.costomer import Customer
from .models.orders import Order


class AdminProduct(admin.ModelAdmin):
    list_display = ['name', 'price','category']


class AdminCategory(admin.ModelAdmin):
    list_display = ['name']


admin.site.register(Project,AdminProduct)
admin.site.register(Category,AdminCategory)
admin.site.register(Customer)
admin.site.register(Order )